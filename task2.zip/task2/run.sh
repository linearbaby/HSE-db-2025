#!/usr/bin/env bash
set -e

IMAGE=hw-hadoop-hive:3.3.6

sudo docker build -t $IMAGE .

sudo docker run --rm \
  --hostname any \
  -e HADOOP_USER_NAME=hdfs \
  -v "$PWD/data:/opt/data" \
  $IMAGE
