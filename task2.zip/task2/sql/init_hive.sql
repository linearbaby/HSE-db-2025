CREATE DATABASE IF NOT EXISTS flights_db;
USE flights_db;

-- Таблица аэропортов
DROP TABLE IF EXISTS airports_raw;
CREATE EXTERNAL TABLE airports_raw (
    airport_code   STRING,
    airport_name   STRING,
    city           STRING,
    state          STRING,
    country        STRING,
    latitude       DOUBLE,
    longitude      DOUBLE
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/data/airports'
TBLPROPERTIES ("skip.header.line.count"="1");

-- Таблица рейсов
DROP TABLE IF EXISTS flights_raw;
CREATE EXTERNAL TABLE flights_raw (
    flight_id      BIGINT,
    flight_date    DATE,
    airline        STRING,
    flight_number  STRING,
    origin         STRING,
    dest           STRING,
    dep_time       STRING,
    arr_time       STRING,
    dep_delay      INT,
    arr_delay      INT,
    distance       INT
)
ROW FORMAT DELIMITED
FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '/data/flights'
TBLPROPERTIES ("skip.header.line.count"="1");

-- количество перелётов по годам
DROP TABLE IF EXISTS mart_flights_per_year;
CREATE TABLE mart_flights_per_year AS
SELECT
    year(flight_date) AS year,
    COUNT(*)          AS flights_cnt
FROM flights_raw
GROUP BY year(flight_date)
ORDER BY year;

-- топ загруженных аэропортов по количеству вылетов (фильтруем мелкие)
DROP TABLE IF EXISTS mart_top_departure_airports;
CREATE TABLE mart_top_departure_airports AS
SELECT
    a.airport_code,
    a.airport_name,
    a.city,
    a.country,
    COUNT(*) AS departures_cnt
FROM flights_raw f
JOIN airports_raw a
  ON f.origin = a.airport_code
WHERE f.origin IS NOT NULL
GROUP BY
    a.airport_code,
    a.airport_name,
    a.city,
    a.country
HAVING COUNT(*) > 1000
ORDER BY departures_cnt DESC;

-- средняя задержка по годам + разница относительно прошлого года;
DROP TABLE IF EXISTS mart_yearly_delay_stats;
CREATE TABLE mart_yearly_delay_stats AS
WITH by_year AS (
  SELECT
      year(flight_date) AS year,
      COUNT(*)          AS flights_cnt,
      AVG(arr_delay)    AS avg_arr_delay
  FROM flights_raw
  WHERE arr_delay IS NOT NULL
  GROUP BY year(flight_date)
)
SELECT
    year,
    flights_cnt,
    avg_arr_delay,
    avg_arr_delay
      - LAG(avg_arr_delay, 1, avg_arr_delay)
        OVER (ORDER BY year) AS avg_delay_diff_prev_year
FROM by_year
ORDER BY year;

-- разбиение рейсов по авиакомпаниям на delayed и on_time
DROP TABLE IF EXISTS mart_airline_delay_bucket;
CREATE TABLE mart_airline_delay_bucket AS
SELECT
    airline,
    'delayed' AS status,
    COUNT(*)  AS flights_cnt
FROM flights_raw
WHERE arr_delay > 15
GROUP BY airline

UNION ALL

SELECT
    airline,
    'on_time' AS status,
    COUNT(*)  AS flights_cnt
FROM flights_raw
WHERE arr_delay <= 15 OR arr_delay IS NULL
GROUP BY airline;

-- топ пар городов (откуда-куда) по количеству рейсов;
DROP TABLE IF EXISTS mart_top_city_pairs;
CREATE TABLE mart_top_city_pairs AS
SELECT
    ao.city  AS origin_city,
    ad.city  AS dest_city,
    COUNT(*) AS flights_cnt
FROM flights_raw f
JOIN airports_raw ao
  ON f.origin = ao.airport_code
JOIN airports_raw ad
  ON f.dest = ad.airport_code
GROUP BY
    ao.city,
    ad.city
HAVING COUNT(*) > 500
ORDER BY flights_cnt DESC;

-- авиакомпании по суммарной пройденной дистанции + ранг
DROP TABLE IF EXISTS mart_airline_distance_rank;
CREATE TABLE mart_airline_distance_rank AS
SELECT
    airline,
    COUNT(*)      AS flights_cnt,
    SUM(distance) AS total_distance,
    RANK() OVER (ORDER BY SUM(distance) DESC) AS distance_rank
FROM flights_raw
WHERE distance IS NOT NULL
GROUP BY airline
ORDER BY total_distance DESC;
