USE flights_db;

-- тест что витрины созданы
SHOW TABLES LIKE 'mart_flights_per_year';
SHOW TABLES LIKE 'mart_top_departure_airports';
SHOW TABLES LIKE 'mart_yearly_delay_stats';
SHOW TABLES LIKE 'mart_airline_delay_bucket';
SHOW TABLES LIKE 'mart_top_city_pairs';
SHOW TABLES LIKE 'mart_airline_distance_rank';

-- первые строки из вью
SELECT * FROM mart_flights_per_year          LIMIT 5;
SELECT * FROM mart_top_departure_airports    LIMIT 5;
SELECT * FROM mart_yearly_delay_stats        LIMIT 5;
SELECT * FROM mart_airline_delay_bucket      LIMIT 5;
SELECT * FROM mart_top_city_pairs            LIMIT 5;
SELECT * FROM mart_airline_distance_rank     LIMIT 5;
