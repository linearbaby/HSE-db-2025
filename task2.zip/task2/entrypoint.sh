#!/usr/bin/env bash
set -e

echo "127.0.0.1 namenode" >> /etc/hosts
echo "127.0.0.1 resourcemanager" >> /etc/hosts

if [ ! -d /opt/hadoop-tmp/dfs/name/current ]; then
  hdfs namenode -format -force -nonInteractive
fi

hdfs --daemon start namenode
hdfs --daemon start datanode

# ждем HDFS, без этого не работает.
for _ in {1..60}; do
  if hdfs dfs -ls / >/dev/null 2>&1; then
    break
  fi
  sleep 1
done

# legacy
yarn --daemon start resourcemanager
yarn --daemon start nodemanager
mapred --daemon start historyserver

# legacy
hdfs dfs -mkdir -p /tmp
hdfs dfs -chmod 1777 /tmp
hdfs dfs -mkdir -p /user/hive/warehouse
hdfs dfs -chmod -R 777 /user/hive

# загружаем ./data
if [ -d "/opt/data" ]; then
  echo "Uploading CSV data from /opt/data to HDFS..."
  hdfs dfs -mkdir -p /data/flights
  hdfs dfs -mkdir -p /data/airports

  # подправь имена под свои файлы
  if [ -f "/opt/data/flights.csv" ]; then
    hdfs dfs -put -f /opt/data/flights.csv /data/flights/
  fi
  if [ -f "/opt/data/airports.csv" ]; then
    hdfs dfs -put -f /opt/data/airports.csv /data/airports/
  fi
fi


if [ ! -d "/opt/hive-metastore/metastore_db" ]; then
  mkdir -p /opt/hive-metastore
  schematool -dbType derby -initSchema --verbose
fi

# основная часть задания.
echo "Running Hive init script..."
hive -f /opt/sql/init_hive.sql

echo "Running marts check script..."
hive -f /opt/sql/check_marts.sql

hive -e "USE flights_db; SHOW TABLES;"